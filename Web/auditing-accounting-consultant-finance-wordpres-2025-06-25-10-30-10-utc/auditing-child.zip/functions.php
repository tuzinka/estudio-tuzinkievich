<?php
add_action( 'wp_enqueue_scripts', 'auditing_child_enqueue_styles', 100 );
function auditing_child_enqueue_styles() {
    wp_enqueue_style( 'auditing-parent', get_theme_file_uri('/style.css') );
}
?>